function normalizeText(value) {
  return String(value || "")
    .replace(/\s+/g, " ")
    .trim();
}

function uniqueTexts(values) {
  return [
    ...new Set(values.map((value) => normalizeText(value)).filter(Boolean)),
  ];
}

function getFirstText(selectors, root = document) {
  for (const selector of selectors) {
    const text = normalizeText(root.querySelector(selector)?.textContent);

    if (text) {
      return text;
    }
  }

  return "";
}

function findSectionByHeading(pattern) {
  const sections = Array.from(
    document.querySelectorAll("main section, section"),
  );

  return (
    sections.find((section) => {
      const heading = getFirstText(["h1", "h2", "h3"], section);
      return pattern.test(heading);
    }) || null
  );
}

function findSection(idFragment, headingPattern) {
  const byId = document
    .querySelector(`section[id*="${idFragment}"], div[id*="${idFragment}"]`)
    ?.closest("section");

  if (byId) {
    return byId;
  }

  return findSectionByHeading(headingPattern);
}

function extractAboutText(section) {
  if (!section) {
    return "";
  }

  const candidates = uniqueTexts(
    Array.from(
      section.querySelectorAll(
        "span[aria-hidden='true'], p, .inline-show-more-text",
      ),
    ).map((element) => normalizeText(element.textContent)),
  );

  return (
    candidates.find(
      (text) => text.length >= 40 && !/^(sobre|about)$/i.test(text),
    ) || ""
  );
}

function extractExperienceTexts(section) {
  if (!section) {
    return [];
  }

  return uniqueTexts(
    Array.from(section.querySelectorAll("li"))
      .map((element) => normalizeText(element.textContent))
      .filter((text) => text.length >= 20),
  ).slice(0, 6);
}

function getProfileData() {
  const name = getFirstText(["main h1", "h1"]);
  const headline = getFirstText([
    "main .text-body-medium.break-words",
    "main .text-body-medium",
    ".text-body-medium.break-words",
    ".text-body-medium",
  ]);
  const aboutSection = findSection("about", /^(sobre|about)$/i);
  const experienceSection = findSection(
    "experience",
    /experi[ee]ncia|experience/i,
  );
  const experiences = uniqueTexts([
    extractAboutText(aboutSection),
    ...extractExperienceTexts(experienceSection),
  ]).slice(0, 6);

  return { name, headline, experiences };
}

console.info("[LinkedIn Analyzer] Content script loaded");

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "GET_PROFILE") {
    const profile = getProfileData();
    console.info("[LinkedIn Analyzer] GET_PROFILE received", profile);
    sendResponse(profile);
  }
});
